export class getBuisneesBody {
    _id: string;
    name: string;
    isDeleted: string;
    createdAt: string;
}
