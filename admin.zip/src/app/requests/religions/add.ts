export class addBody {
    name: string;
}

