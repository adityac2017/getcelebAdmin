export class updateBody {
    Id :'';
    name: string;
    index: any;

  
}

