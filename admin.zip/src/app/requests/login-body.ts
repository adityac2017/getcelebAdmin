export class LoginBody {
    email: string;
    password: string;
}
