export class admin {
    email: string;
  
}