export class addTimeSlotBody {
    timeZone: string;
    startTime: string;
    endTime: string;
}

