export class updateUserBody {
    userId :'';
    name: string;
    phoneNumber: string;
    
    index : any
}

