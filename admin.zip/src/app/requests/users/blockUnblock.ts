export class blockUnblock {
    isBlocked :number;
    userId: string; 
    clientId: string;
    index : any
}

