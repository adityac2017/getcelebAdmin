export class DocumentsBody {
    userId: string;
    _id: string;
    drivingLicence: string;
    vehicleRegistration: string;
    vehicleInsurance: string;
    isDeleted: string;
    isApproved: any;
    isVerified:string;
    driverId: any;
    index: any;
   
}