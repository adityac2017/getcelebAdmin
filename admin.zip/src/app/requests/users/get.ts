export class getUsersBody {
    total : any;
    _id: string;
    name: string;
    delete_status: string;
    phoneNumber: string;
    email: string;
    avatar: string;
    activate_deactivate_status: string;
    referralcode: string;
    password: string;
    socialId: string;
    isVerified: string;
    userType: string;
    isFullUrl: string;
    emaaccountTypeil: string;
    buisnessName: string;
    buisnessType: string;
    buisnessEmail: string;
    buisnessPhone: string;
    user_lat: string;
    user_long: string;
    referralCode: string;
    isDeleted: string;
    isBlocked: string;
    createdAt: string;
}
