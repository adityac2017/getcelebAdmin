export class PaginationBody {
    skip: number;
    limit: number;
    searchText: string;
    clientId:string;
    requestId:string;
}
