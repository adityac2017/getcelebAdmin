export class addBody {
    clientEmail: string;
    clientName: string;
    clientPassword: string;
    clientPhone: string;
    description: string;
    instagramId: string;
    campaignType: number;
    // introVedio: string;
    tag: any[] = [];
    title: string;
    vedioPrice: string;
    campaignDesc: string;
    campaignTime: string;
    campaignImage: string;
    categoryId:string;
}

