export class updateBody {
    clientId: string;
    clientEmail: string;
    clientName: string;
    clientPhone: string;
    instagramId: string;
    vedioPrice: string;
    description: string;
    clientPassword: string;
    campaignType: number;
    title: string;
    tag: any[] = [];
    index: any;
    campaignDesc: string;
    campaignTime: any;
    campaignImage: string;
    categoryId:string;

}

